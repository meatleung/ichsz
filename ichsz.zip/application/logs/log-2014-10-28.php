<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2014-10-28 20:31:23 --> Config Class Initialized
DEBUG - 2014-10-28 20:31:23 --> Hooks Class Initialized
DEBUG - 2014-10-28 20:31:23 --> Utf8 Class Initialized
DEBUG - 2014-10-28 20:31:23 --> UTF-8 Support Enabled
DEBUG - 2014-10-28 20:31:23 --> URI Class Initialized
DEBUG - 2014-10-28 20:31:23 --> Router Class Initialized
DEBUG - 2014-10-28 20:31:23 --> Output Class Initialized
DEBUG - 2014-10-28 20:31:23 --> Security Class Initialized
DEBUG - 2014-10-28 20:31:23 --> Input Class Initialized
DEBUG - 2014-10-28 20:31:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-10-28 20:31:23 --> Language Class Initialized
DEBUG - 2014-10-28 20:31:23 --> Loader Class Initialized
DEBUG - 2014-10-28 20:31:23 --> Controller Class Initialized
DEBUG - 2014-10-28 20:31:23 --> Helper loaded: url_helper
DEBUG - 2014-10-28 20:31:23 --> Model Class Initialized
DEBUG - 2014-10-28 20:31:23 --> Model Class Initialized
DEBUG - 2014-10-28 20:31:23 --> Database Driver Class Initialized
ERROR - 2014-10-28 20:31:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\ichsz\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-10-28 20:31:23 --> Table Class Initialized
DEBUG - 2014-10-28 20:31:23 --> File loaded: application/views/head.php
DEBUG - 2014-10-28 20:31:23 --> File loaded: application/views/navbar.php
DEBUG - 2014-10-28 20:31:23 --> File loaded: application/views/icdig.php
DEBUG - 2014-10-28 20:31:23 --> File loaded: application/views/footer.php
DEBUG - 2014-10-28 20:31:23 --> File loaded: application/views/page.php
DEBUG - 2014-10-28 20:31:23 --> Final output sent to browser
DEBUG - 2014-10-28 20:31:23 --> Total execution time: 0.2148
DEBUG - 2014-10-28 20:31:25 --> Config Class Initialized
DEBUG - 2014-10-28 20:31:25 --> Hooks Class Initialized
DEBUG - 2014-10-28 20:31:25 --> Utf8 Class Initialized
DEBUG - 2014-10-28 20:31:25 --> UTF-8 Support Enabled
DEBUG - 2014-10-28 20:31:25 --> URI Class Initialized
DEBUG - 2014-10-28 20:31:25 --> Router Class Initialized
DEBUG - 2014-10-28 20:31:25 --> Output Class Initialized
DEBUG - 2014-10-28 20:31:25 --> Security Class Initialized
DEBUG - 2014-10-28 20:31:25 --> Input Class Initialized
DEBUG - 2014-10-28 20:31:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-10-28 20:31:25 --> Language Class Initialized
DEBUG - 2014-10-28 20:31:25 --> Loader Class Initialized
DEBUG - 2014-10-28 20:31:25 --> Controller Class Initialized
DEBUG - 2014-10-28 20:31:25 --> Helper loaded: url_helper
ERROR - 2014-10-28 20:31:25 --> Severity: Warning  --> Missing argument 1 for Detail::index() C:\wamp\www\ichsz\application\controllers\detail.php 9
ERROR - 2014-10-28 20:31:25 --> Severity: Notice  --> Undefined variable: id C:\wamp\www\ichsz\application\controllers\detail.php 11
DEBUG - 2014-10-28 20:31:25 --> Final output sent to browser
DEBUG - 2014-10-28 20:31:25 --> Total execution time: 0.0262
DEBUG - 2014-10-28 20:34:27 --> Config Class Initialized
DEBUG - 2014-10-28 20:34:27 --> Hooks Class Initialized
DEBUG - 2014-10-28 20:34:27 --> Utf8 Class Initialized
DEBUG - 2014-10-28 20:34:27 --> UTF-8 Support Enabled
DEBUG - 2014-10-28 20:34:27 --> URI Class Initialized
DEBUG - 2014-10-28 20:34:27 --> Router Class Initialized
DEBUG - 2014-10-28 20:34:27 --> Output Class Initialized
DEBUG - 2014-10-28 20:34:27 --> Security Class Initialized
DEBUG - 2014-10-28 20:34:27 --> Input Class Initialized
DEBUG - 2014-10-28 20:34:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-10-28 20:34:27 --> Language Class Initialized
DEBUG - 2014-10-28 20:34:27 --> Loader Class Initialized
DEBUG - 2014-10-28 20:34:27 --> Controller Class Initialized
DEBUG - 2014-10-28 20:34:27 --> Helper loaded: url_helper
DEBUG - 2014-10-28 20:34:27 --> Model Class Initialized
DEBUG - 2014-10-28 20:34:27 --> Model Class Initialized
DEBUG - 2014-10-28 20:34:27 --> Database Driver Class Initialized
ERROR - 2014-10-28 20:34:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\ichsz\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-10-28 20:34:27 --> Table Class Initialized
DEBUG - 2014-10-28 20:34:27 --> File loaded: application/views/head.php
DEBUG - 2014-10-28 20:34:27 --> File loaded: application/views/navbar.php
DEBUG - 2014-10-28 20:34:27 --> File loaded: application/views/icdig.php
DEBUG - 2014-10-28 20:34:27 --> File loaded: application/views/footer.php
DEBUG - 2014-10-28 20:34:27 --> File loaded: application/views/page.php
DEBUG - 2014-10-28 20:34:27 --> Final output sent to browser
DEBUG - 2014-10-28 20:34:27 --> Total execution time: 0.0565
DEBUG - 2014-10-28 20:34:29 --> Config Class Initialized
DEBUG - 2014-10-28 20:34:29 --> Hooks Class Initialized
DEBUG - 2014-10-28 20:34:29 --> Utf8 Class Initialized
DEBUG - 2014-10-28 20:34:29 --> UTF-8 Support Enabled
DEBUG - 2014-10-28 20:34:29 --> URI Class Initialized
DEBUG - 2014-10-28 20:34:29 --> Router Class Initialized
DEBUG - 2014-10-28 20:34:29 --> Output Class Initialized
DEBUG - 2014-10-28 20:34:29 --> Security Class Initialized
DEBUG - 2014-10-28 20:34:29 --> Input Class Initialized
DEBUG - 2014-10-28 20:34:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-10-28 20:34:29 --> Language Class Initialized
DEBUG - 2014-10-28 20:34:29 --> Loader Class Initialized
DEBUG - 2014-10-28 20:34:29 --> Controller Class Initialized
DEBUG - 2014-10-28 20:34:29 --> Helper loaded: url_helper
DEBUG - 2014-10-28 20:34:29 --> Final output sent to browser
DEBUG - 2014-10-28 20:34:29 --> Total execution time: 0.1170
DEBUG - 2014-10-28 20:34:33 --> Config Class Initialized
DEBUG - 2014-10-28 20:34:33 --> Hooks Class Initialized
DEBUG - 2014-10-28 20:34:33 --> Utf8 Class Initialized
DEBUG - 2014-10-28 20:34:33 --> UTF-8 Support Enabled
DEBUG - 2014-10-28 20:34:33 --> URI Class Initialized
DEBUG - 2014-10-28 20:34:33 --> Router Class Initialized
DEBUG - 2014-10-28 20:34:33 --> Output Class Initialized
DEBUG - 2014-10-28 20:34:33 --> Security Class Initialized
DEBUG - 2014-10-28 20:34:33 --> Input Class Initialized
DEBUG - 2014-10-28 20:34:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-10-28 20:34:33 --> Language Class Initialized
DEBUG - 2014-10-28 20:34:33 --> Loader Class Initialized
DEBUG - 2014-10-28 20:34:33 --> Controller Class Initialized
DEBUG - 2014-10-28 20:34:33 --> Helper loaded: url_helper
DEBUG - 2014-10-28 20:34:33 --> Final output sent to browser
DEBUG - 2014-10-28 20:34:33 --> Total execution time: 0.0243
DEBUG - 2014-10-28 20:34:34 --> Config Class Initialized
DEBUG - 2014-10-28 20:34:34 --> Hooks Class Initialized
DEBUG - 2014-10-28 20:34:34 --> Utf8 Class Initialized
DEBUG - 2014-10-28 20:34:34 --> UTF-8 Support Enabled
DEBUG - 2014-10-28 20:34:34 --> URI Class Initialized
DEBUG - 2014-10-28 20:34:34 --> Router Class Initialized
DEBUG - 2014-10-28 20:34:34 --> Output Class Initialized
DEBUG - 2014-10-28 20:34:34 --> Security Class Initialized
DEBUG - 2014-10-28 20:34:34 --> Input Class Initialized
DEBUG - 2014-10-28 20:34:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-10-28 20:34:34 --> Language Class Initialized
DEBUG - 2014-10-28 20:34:34 --> Loader Class Initialized
DEBUG - 2014-10-28 20:34:34 --> Controller Class Initialized
DEBUG - 2014-10-28 20:34:34 --> Helper loaded: url_helper
DEBUG - 2014-10-28 20:34:34 --> Final output sent to browser
DEBUG - 2014-10-28 20:34:34 --> Total execution time: 0.0240
DEBUG - 2014-10-28 20:34:35 --> Config Class Initialized
DEBUG - 2014-10-28 20:34:35 --> Hooks Class Initialized
DEBUG - 2014-10-28 20:34:35 --> Utf8 Class Initialized
DEBUG - 2014-10-28 20:34:35 --> UTF-8 Support Enabled
DEBUG - 2014-10-28 20:34:35 --> URI Class Initialized
DEBUG - 2014-10-28 20:34:35 --> Router Class Initialized
DEBUG - 2014-10-28 20:34:35 --> Output Class Initialized
DEBUG - 2014-10-28 20:34:35 --> Security Class Initialized
DEBUG - 2014-10-28 20:34:35 --> Input Class Initialized
DEBUG - 2014-10-28 20:34:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-10-28 20:34:35 --> Language Class Initialized
DEBUG - 2014-10-28 20:34:35 --> Loader Class Initialized
DEBUG - 2014-10-28 20:34:35 --> Controller Class Initialized
DEBUG - 2014-10-28 20:34:35 --> Helper loaded: url_helper
DEBUG - 2014-10-28 20:34:35 --> Final output sent to browser
DEBUG - 2014-10-28 20:34:35 --> Total execution time: 0.0249
DEBUG - 2014-10-28 20:36:16 --> Config Class Initialized
DEBUG - 2014-10-28 20:36:16 --> Hooks Class Initialized
DEBUG - 2014-10-28 20:36:16 --> Utf8 Class Initialized
DEBUG - 2014-10-28 20:36:16 --> UTF-8 Support Enabled
DEBUG - 2014-10-28 20:36:16 --> URI Class Initialized
DEBUG - 2014-10-28 20:36:16 --> Router Class Initialized
DEBUG - 2014-10-28 20:36:16 --> Output Class Initialized
DEBUG - 2014-10-28 20:36:16 --> Security Class Initialized
DEBUG - 2014-10-28 20:36:16 --> Input Class Initialized
DEBUG - 2014-10-28 20:36:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-10-28 20:36:16 --> Language Class Initialized
DEBUG - 2014-10-28 20:36:16 --> Loader Class Initialized
DEBUG - 2014-10-28 20:36:16 --> Controller Class Initialized
DEBUG - 2014-10-28 20:36:16 --> Helper loaded: url_helper
DEBUG - 2014-10-28 20:36:16 --> Model Class Initialized
DEBUG - 2014-10-28 20:36:16 --> Model Class Initialized
DEBUG - 2014-10-28 20:36:16 --> Database Driver Class Initialized
ERROR - 2014-10-28 20:36:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\ichsz\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-10-28 20:36:16 --> Table Class Initialized
DEBUG - 2014-10-28 20:36:16 --> File loaded: application/views/head.php
DEBUG - 2014-10-28 20:36:16 --> File loaded: application/views/navbar.php
DEBUG - 2014-10-28 20:36:16 --> File loaded: application/views/icdig.php
DEBUG - 2014-10-28 20:36:16 --> File loaded: application/views/footer.php
DEBUG - 2014-10-28 20:36:16 --> File loaded: application/views/page.php
DEBUG - 2014-10-28 20:36:16 --> Final output sent to browser
DEBUG - 2014-10-28 20:36:16 --> Total execution time: 0.0552
DEBUG - 2014-10-28 20:36:18 --> Config Class Initialized
DEBUG - 2014-10-28 20:36:18 --> Hooks Class Initialized
DEBUG - 2014-10-28 20:36:18 --> Utf8 Class Initialized
DEBUG - 2014-10-28 20:36:18 --> UTF-8 Support Enabled
DEBUG - 2014-10-28 20:36:18 --> URI Class Initialized
DEBUG - 2014-10-28 20:36:18 --> Router Class Initialized
DEBUG - 2014-10-28 20:36:18 --> Output Class Initialized
DEBUG - 2014-10-28 20:36:18 --> Security Class Initialized
DEBUG - 2014-10-28 20:36:18 --> Input Class Initialized
DEBUG - 2014-10-28 20:36:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-10-28 20:36:18 --> Language Class Initialized
DEBUG - 2014-10-28 20:36:18 --> Loader Class Initialized
DEBUG - 2014-10-28 20:36:18 --> Controller Class Initialized
DEBUG - 2014-10-28 20:36:18 --> Helper loaded: url_helper
DEBUG - 2014-10-28 20:36:18 --> Final output sent to browser
DEBUG - 2014-10-28 20:36:18 --> Total execution time: 0.0270
DEBUG - 2014-10-28 20:36:19 --> Config Class Initialized
DEBUG - 2014-10-28 20:36:19 --> Hooks Class Initialized
DEBUG - 2014-10-28 20:36:19 --> Utf8 Class Initialized
DEBUG - 2014-10-28 20:36:19 --> UTF-8 Support Enabled
DEBUG - 2014-10-28 20:36:19 --> URI Class Initialized
DEBUG - 2014-10-28 20:36:19 --> Router Class Initialized
DEBUG - 2014-10-28 20:36:19 --> Output Class Initialized
DEBUG - 2014-10-28 20:36:19 --> Security Class Initialized
DEBUG - 2014-10-28 20:36:19 --> Input Class Initialized
DEBUG - 2014-10-28 20:36:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-10-28 20:36:19 --> Language Class Initialized
DEBUG - 2014-10-28 20:36:19 --> Loader Class Initialized
DEBUG - 2014-10-28 20:36:19 --> Controller Class Initialized
DEBUG - 2014-10-28 20:36:19 --> Helper loaded: url_helper
DEBUG - 2014-10-28 20:36:19 --> Final output sent to browser
DEBUG - 2014-10-28 20:36:19 --> Total execution time: 0.0242
DEBUG - 2014-10-28 20:36:20 --> Config Class Initialized
DEBUG - 2014-10-28 20:36:20 --> Hooks Class Initialized
DEBUG - 2014-10-28 20:36:20 --> Utf8 Class Initialized
DEBUG - 2014-10-28 20:36:20 --> UTF-8 Support Enabled
DEBUG - 2014-10-28 20:36:20 --> URI Class Initialized
DEBUG - 2014-10-28 20:36:20 --> Router Class Initialized
DEBUG - 2014-10-28 20:36:20 --> Output Class Initialized
DEBUG - 2014-10-28 20:36:20 --> Security Class Initialized
DEBUG - 2014-10-28 20:36:20 --> Input Class Initialized
DEBUG - 2014-10-28 20:36:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-10-28 20:36:20 --> Language Class Initialized
DEBUG - 2014-10-28 20:36:20 --> Loader Class Initialized
DEBUG - 2014-10-28 20:36:20 --> Controller Class Initialized
DEBUG - 2014-10-28 20:36:20 --> Helper loaded: url_helper
DEBUG - 2014-10-28 20:36:20 --> Final output sent to browser
DEBUG - 2014-10-28 20:36:20 --> Total execution time: 0.0242
DEBUG - 2014-10-28 20:36:22 --> Config Class Initialized
DEBUG - 2014-10-28 20:36:22 --> Hooks Class Initialized
DEBUG - 2014-10-28 20:36:22 --> Utf8 Class Initialized
DEBUG - 2014-10-28 20:36:22 --> UTF-8 Support Enabled
DEBUG - 2014-10-28 20:36:22 --> URI Class Initialized
DEBUG - 2014-10-28 20:36:22 --> Router Class Initialized
DEBUG - 2014-10-28 20:36:22 --> Output Class Initialized
DEBUG - 2014-10-28 20:36:22 --> Security Class Initialized
DEBUG - 2014-10-28 20:36:22 --> Input Class Initialized
DEBUG - 2014-10-28 20:36:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-10-28 20:36:22 --> Language Class Initialized
DEBUG - 2014-10-28 20:36:22 --> Loader Class Initialized
DEBUG - 2014-10-28 20:36:22 --> Controller Class Initialized
DEBUG - 2014-10-28 20:36:22 --> Helper loaded: url_helper
DEBUG - 2014-10-28 20:36:22 --> Final output sent to browser
DEBUG - 2014-10-28 20:36:22 --> Total execution time: 0.0240
