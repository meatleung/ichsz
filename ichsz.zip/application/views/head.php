﻿<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="IC,元器件,电子元器件,元件,回收,IC回收,ic回收站,电子元件回收,回收ic,回收电子料,回收内存芯片,呆滞IC,IC呆料,www.ichsz.com" />
<meta name="description" content="有大批量的呆滞IC找不到买家？想在呆滞IC中淘宝？进入IC回收站，一步找到海量IC呆料的买家和卖家。" />
<meta name="baidu-site-verification" content="lgdtlbJ13t" />
<title><?php echo $title; ?></title>

<!--设置网页小图标、书签图标-->
<link rel="shortcut icon" href="<?php echo base_url() ?>favicon.ico"/>
<link rel="bookmark" href="<?php echo base_url() ?>favicon.ico"/>

<!--导入基本CSS样式-->
<link href="<?php echo base_url() ?>css/main.css" rel="stylesheet" type="text/css" />

<?php echo $head; ?>