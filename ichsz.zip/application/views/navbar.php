<div style="text-align:center;">
<p id="nav">
<span><img src="<?php echo base_url("image/logo.png"); ?>" alt="IC回收站logo" title="IC回收站logo"></img></span>
<!--
<span><?php echo anchor(base_url(), '淘IC散料'); ?></span>
-->
<span><?php echo anchor(site_url('massic'), '批量呆料'); ?></span>
<span><?php echo anchor(site_url('ad'), '收呆料'); ?></span>
<span><?php echo anchor(site_url('contactus'), '联系我们'); ?></span>
</p>
</div>