<div id="top_bg">
	<div class="top">
		<a class="logo_l" title="IC回收站"></a>
		<div class="nav_z">
			<ul id="navul" class="cl">
				<li>
					<?php echo anchor('/', '首页'); ?>
				</li>
				<li>
					<?php echo anchor('adservice', '广告收费标准');?>
				</li>
				<li>
					<?php echo anchor('contactus', '联系方式');?>
				</li>
			</ul>
		</div>
	</div>
</div>