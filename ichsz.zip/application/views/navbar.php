<div class="nav">
	<ul style="left: 35%;">
		<li class="navlogo">
		</li>
		<li>
			<?php echo anchor('/', '首页'); ?>
		</li>
		<li>
			<?php echo anchor('icdig', '淘IC'); ?>
		</li>
		<li>
			<?php echo anchor('adservice', '广告收费标准');?>
		</li>
		<li>
			<?php echo anchor('contactus', '联系方式');?>
		</li>
	</ul>
</div>

