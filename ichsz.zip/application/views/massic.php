﻿<div style="text-align:center;">
<p id="nav">
<span>仓库的IC呆料卖不掉？</span>
<span><?php echo anchor('contactus', '点击此处');?></span>
<span>联系我们,将呆料信息放在IC回收站展示，本服务永久免费。</span>
</p>
</div>
	<?php	
		echo $this->table->generate($results);
	?>