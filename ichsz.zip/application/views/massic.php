﻿<div style="text-align:center;">
<p>
<span>您还在为仓库的IC呆料发愁吗？和我们</span>
<span><a target="_blank" href="tencent://message/?uin=2079311233&site=qq&Menu=yes"><img src='<?php echo base_url(); ?>image/qqtalk.png' alt="点击这里给我发消息" title="点击这里给我发消息"/></a></span>
<span>,我们会为您卖到最高价。</span>
</p>
</div>
	<?php	
		echo $this->table->generate($results);
	?>