﻿<a href="<?php echo base_url()?>image/ic/1/1_b1.jpg" class="jqzoom"   title="triumph" >
<img src="<?php echo base_url()?>image/ic/1/1_b1.jpg"  title="triumph"  style="width:320px;height:240px;border: 4px solid #666;">
</a>