﻿<div style="text-align:center;">
<p id="nav">
<span><a href="#" onClick="window.external.addFavorite('http://www.ichsz.com','IC回收站')" title="收藏本站">点击此处</a></span>
<span style="letter-spacing:2px;">可收藏本站,方便快捷地获取呆料信息</span>
</p> 
	<?php	
		echo $this->table->generate();
	?>