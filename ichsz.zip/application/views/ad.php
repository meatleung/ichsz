﻿<div style="text-align:center;">
<p id="nav">
<span>想让有呆料的人联系你吗？</span>
<span><?php echo anchor('contactus', '点击此处');?></span>
<span>,将您的企业信息留在IC回收站，本服务永久免费。</span>
</p>
</div>
	<?php	
		echo $this->table->generate($results);
	?>