﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<script src="http://libs.baidu.com/jquery/1.6.0/jquery.js"></script>
<script src="<?php echo base_url() ; ?>/js/test.js"></script>
</head>
<body>
<button id="1">123</button>
<p id="qqq"></p>
</body>
</html>
