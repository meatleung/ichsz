﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<?php echo $head; ?>
</head>
<body>
<table class="container">
<tr><td>
<?php echo $navbar;?>
</tr></td><tr><td>
<?php echo $content;?>
</tr></td><tr><td>
<?php echo $footer;?>
</tr></td></table>
</body>
</html>
