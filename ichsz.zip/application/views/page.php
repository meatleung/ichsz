﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="IC,元器件,电子元器件,元件,回收,IC回收,ic回收站,电子元件回收,回收ic,回收电子料,回收内存芯片,呆滞IC,www.ichsz.com" />
<meta name="description" content="IC回收站(www.ichsz.com)为收购呆滞IC的企业提供免费的广告服务。您足不出户即可在本网站查到多家IC收购商家的联系方式，减少寻找的时间。" />
<meta name="baidu-site-verification" content="lgdtlbJ13t" />
<title><?php echo $title; ?></title>
<link rel="shortcut icon" href="<?php echo base_url() ?>favicon.ico"/>
<link rel="bookmark" href="<?php echo base_url() ?>favicon.ico"/>
<link href="<?php echo base_url() ?>css/navbar.css" rel="stylesheet" type="text/css" /><!--导入导航条CSS样式-->
<link href="<?php echo base_url() ?>css/table.css" rel="stylesheet" type="text/css" />
<!--导入表格CSS样式-->
<script type="text/javascript" src="<?php echo base_url() ?>js/jquery.min.js"></script>
<script type="text/javascript"  src="<?php echo base_url() ?>js/nav.js"></script>
<style>
    .longbanner {text-align:center;position:relative;top:17px;} <!--定义首页长banner样式-->
</style>

</head>
<body>
<?php echo $navbar; ?>
<?php echo $content; ?>
<?php echo $footer; ?>
</body>
</html>
