﻿<script type="text/javascript">
var _bdhmProtocol = (("https:" == document.location.protocol) ? " https://" : " http://");
document.write(unescape("%3Cscript src='" + _bdhmProtocol + "hm.baidu.com/h.js%3F408524a0d799a7a235feebc864400c61' type='text/javascript'%3E%3C/script%3E"));
</script>
