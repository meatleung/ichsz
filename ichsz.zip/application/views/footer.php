﻿<div style="text-align:center;height:40px;">
<script type="text/javascript">var cnzz_protocol = (("https:" == document.location.protocol) ? " https://" : " http://");document.write(unescape("%3Cspan id='cnzz_stat_icon_1253405987'%3E%3C/span%3E%3Cscript src='" + cnzz_protocol + "s6.cnzz.com/stat.php%3Fid%3D1253405987%26show%3Dpic2' type='text/javascript'%3E%3C/script%3E"));</script>
</div>