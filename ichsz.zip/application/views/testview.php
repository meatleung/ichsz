﻿<?php 
   echo $ad[1];
?>