﻿<!--展示small尺寸照片-->
<a href="<?php echo base_url()?>image/ic/<?php echo $id?>/<?php echo $id?>_b1.jpg" rel='gal' class="jqzoom" title="<?php echo $icdetail->model;?>">
<div style="padding-left:60px">
<img src="<?php echo base_url()?>image/ic/<?php echo $id?>/<?php echo $id?>_b1.jpg"  title="<?php echo $icdetail->model;?>" style="border:3px solid green;width:308px;height:247px;"></div>
</a>
